from botcity.web import WebBot, Browser
from botcity.core import DesktopBot
# Uncomment the line below for integrations with BotMaestro
# Using the Maestro SDK
# from botcity.maestro import *
import time
import pandas as pd
from tqdm import tqdm
import docx

# PARA LER A MSG (DOCX)


def readtxt(filename):
    doc = docx.Document(filename)
    fullText = []
    for para in doc.paragraphs:
        fullText.append(para.text)
    return '\n'.join(fullText)


msg = readtxt('/Auto Poster Facebook/config/msg.docx')

# Importa Tabela de Grupos
grupos_df = pd.read_excel("/Auto Poster Facebook/config/groups.xlsx")

# Importa Tabela Config
config_df = pd.read_excel("/Auto Poster Facebook/config/config.xlsx")
df = pd.DataFrame(config_df)
email = df.at[0, 'email']
espera = str(df.at[0, 'time'])
img = df.at[0, 'img']
licenca = df.at[0, "license"]


class Bot(DesktopBot):

    #Função para adicionar foto
    def addFoto(self):
        if self.find("addFoto_click", matching=0.97, waiting_time=10000):
            self.click()
            self.move_relative(0, -100)
            self.scroll_down(999)
            if self.find("addFoto2_click", matching=0.97, waiting_time=10000):
                self.click()
                if self.find("escreverFoto_click", matching=0.97, waiting_time=10000):
                    self.click()
                    self.paste(img)
                    self.enter()

    def action(self, execution=None):
        # Configure whether or not to run on headless mode
        #self.headless = False

        # Instantiate a DesktopBot
        #desktop_bot = DesktopBot()
        # Execute operations with the DesktopBot as desired
        # desktop_bot.control_a()
        # desktop_bot.control_c()
        # desktop_bot.get_clipboard()

        # Uncomment to change the default Browser to Firefox
        # self.browser = Browser.FIREFOX

        # Uncomment to set the WebDriver path
        #self.driver_path = '/Auto Poster Facebook/chromedriver.exe'

        # Fetch the Activity ID from the task:
        # task = self.maestro.get_task(execution.task_id)
        # activity_id = task.activity_id

        # Opens the BotCity website.
        self.browse("https://www.facebook.com")

        # Espera enquanto faz o login
        while not self.find("acharChat", matching=0.97, waiting_time=10000):
            self.not_found("acharChat")
            print('Ainda nao fez login')
            time.sleep(1)

        # Entra em cada link
        for i, link in tqdm(enumerate(grupos_df['Grupos'])):
            self.browse(link, location=0)
            print(f'abriu link {i}')
            try:
                # Modelo 1
                if self.find("modelo1", matching=0.97, waiting_time=10000):
                    self.click()

                    # Escrever publicaçao 1
                    if self.find("publick_post_click", matching=0.97, waiting_time=10000):
                        self.paste(msg)
                        # Add Foto
                        self.addFoto()
                    # Escrever publicaçao 2
                    elif self.find("write_somenthing_click", matching=0.97, waiting_time=10000):
                        self.paste(msg)

                # Modelo 2
                elif self.find("modelo2", matching=0.97, waiting_time=10000):
                    self.click()

                    # Escrever publicaçao 1
                    if self.find("publick_post_click", matching=0.97, waiting_time=10000):
                        self.paste(msg)
                    # Escrever publicaçao 2
                    elif self.find("write_somenthing_click", matching=0.97, waiting_time=10000):
                        self.paste(msg)

                # Modelo3
                elif self.find("modelo3", matching=0.97, waiting_time=10000):
                    self.click()

                    # Escrever publicaçao 1
                    if self.find("publick_post_click", matching=0.97, waiting_time=10000):
                        self.paste(msg)
                    # Escrever publicaçao 2
                    elif self.find("write_somenthing_click", matching=0.97, waiting_time=10000):
                        self.paste(msg)

                print('Encontrou')
                time.sleep(3)
            except:
                print('nao encontrou modelo1')
                time.sleep(3)
                continue

                # Uncomment to mark this task as finished on BotMaestro
                # self.maestro.finish_task(
                #     task_id=execution.task_id,
                #     status=AutomationTaskFinishStatus.SUCCESS,
                #     message="Task Finished OK."
                # )

                # Wait for 10 seconds before closing
        self.wait(10000)

        # Stop the browser and clean up
        # self.stop_browser()

    def not_found(self, label):
        print(f"Element not found: {label}")


if __name__ == '__main__':
    Bot.main()
